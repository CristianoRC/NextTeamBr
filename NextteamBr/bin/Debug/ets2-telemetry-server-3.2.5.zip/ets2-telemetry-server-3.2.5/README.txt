Welcome to the ETS2 Telemetry Web Server and Mobile Dashboard!

================
Folder structure
================

	----------
	| mobile |  contains compiled native mobile applications
	----------
	| server |  contains compiled dashboard server, mobile dashboard and all skins
	----------
	| source |  original source code of the project
	----------

Just run "server\Ets2Telemetry.exe" to start the server and connect your personal HTML5 mobile dashboard!

================
     LINKS
================

New versions, updates, help & FAQ are always available at this URL: 

https://github.com/Funbit/ets2-telemetry-server

IMPORTANT !!!
I don't recommend to download server from anywhere else, except the above link, because it might contain viruses!
You may download skins from other sites, but make sure that skin does not contain EXE files inside!

================
    LICENSE
================

GNU General Public License v3 (GPL-3). Please read LICENSE file for details.


================
    CONTACTS
================

You may contact the author using this email: contact@funbit.info

Funbit (c) 2015